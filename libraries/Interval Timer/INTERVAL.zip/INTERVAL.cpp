#include <INTERVAL.h>
bool DoINTERVAL = false; // Merker für das Interval Macro
